Uso de uma API para pegar a última pessoa a dar um commit no repositório "dev-aberto" da disciplina.

https://github.com/Insper/open-dev.git
